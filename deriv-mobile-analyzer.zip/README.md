# Deriv Mobile Digit Analyzer

This version is designed for Android Chrome and can run as a static web app.

## Easiest use
1. Put this folder on a static web host such as GitHub Pages, Cloudflare Pages, Netlify, or another static host.
2. Open the resulting HTTPS address in Chrome on your phone.
3. Select a Volatility symbol.
4. Press CONNECT.
5. Wait for historical/live ticks.
6. Use RUN BACKTEST before considering any trading decision.

The browser connects directly to Deriv's public WebSocket feed. No Deriv password or API token is stored by this app.

## Important
- This is an analysis/backtesting tool, not a guaranteed predictor.
- It does NOT place trades.
- A high historical frequency does not prove the next digit will be the same.
- For real-money execution, build and validate a separate authenticated backend and start with demo trading.
