const WS="wss://ws.derivws.com/websockets/v3?app_id=1089";
let ws=null, ticks=[], running=false, pipSize=null;

const $=id=>document.getElementById(id);
function log(s){$("log").textContent=(new Date()).toLocaleTimeString()+"  "+s+"\n"+$("log").textContent.slice(0,5000)}
function setStatus(s,on=false){$("status").textContent=s;$("dot").className="dot"+(on?" on":"")}

function digitFromQuote(q,pip){
  const decimals = Number(pip ?? 2);
  const scaled=Math.round(Number(q)*10**decimals);
  return Math.abs(scaled)%10;
}
function counts(a){const c=Array(10).fill(0);for(const d of a)c[d]++;return c}
function render(){
  const n=ticks.length;if(!n)return;
  const c=counts(ticks), total=n;
  const order=[...Array(10).keys()].sort((a,b)=>c[b]-c[a]);
  const best=order[0], worst=order[9];
  const matchRate=c[best]/total, diffRate=1-c[worst]/total;
  $("match").textContent=best;$("diff").textContent=worst;
  $("matchRate").textContent=(matchRate*100).toFixed(1)+"%";
  $("confidence").textContent=Math.max(matchRate,diffRate)*100 .toFixed(1)+"%";
  $("signal").textContent=(matchRate>=0.15?"ANALYZE MATCH":"WAIT");
  $("count").textContent=`${n} ticks`;
  $("recent").textContent=ticks.slice(-40).join(" ");
  $("digits").innerHTML=c.map((x,i)=>`<div class="digit"><b>${i}</b><span>${(x/total*100).toFixed(1)}%</span><div class="bar"><div class="fill" style="width:${x/total*100}%"></div></div></div>`).join("");
}
function requestHistory(){
  ws.send(JSON.stringify({ticks_history:$("symbol").value,count:Number($("window").value),end:"latest",style:"ticks"}));
  ws.send(JSON.stringify({ticks:$("symbol").value,subscribe:1}));
}
function connect(){
  if(ws){ws.close();ws=null}
  ticks=[];render();setStatus("Connecting…");
  ws=new WebSocket(WS);
  ws.onopen=()=>{running=true;setStatus("Connected",true);log("Connected");requestHistory()};
  ws.onclose=()=>{running=false;setStatus("Disconnected");log("Connection closed")};
  ws.onerror=()=>{setStatus("Connection error");log("WebSocket error")};
  ws.onmessage=e=>{
    const m=JSON.parse(e.data);
    if(m.error){log("API: "+m.error.message);return}
    if(m.msg_type==="history"){
      pipSize=m.pip_size;
      ticks=(m.history?.prices||[]).map(x=>digitFromQuote(x,pipSize));
      ticks=ticks.slice(-Number($("window").value));render();log("Historical ticks loaded");
    }
    if(m.msg_type==="tick"){
      pipSize=m.tick.pip_size ?? pipSize;
      ticks.push(digitFromQuote(m.tick.quote,pipSize));
      const max=Number($("window").value);if(ticks.length>max)ticks=ticks.slice(-max);
      render();
    }
  }
}
function backtest(){
  const a=ticks;if(a.length<100){$("backtestOut").textContent="Need at least 100 ticks.";return}
  let correct=0,total=0;
  const start=50;
  for(let i=start;i<a.length-1;i++){
    const hist=a.slice(Math.max(0,i-100),i), c=counts(hist);
    const best=c.indexOf(Math.max(...c));
    if(a[i+1]===best)correct++;
    total++;
  }
  const acc=correct/total*100;
  $("backtestOut").textContent=`Simple frequency baseline: ${acc.toFixed(2)}% next-digit hit rate over ${total} out-of-sample steps. This is a diagnostic baseline, not a trading guarantee.`;
}
$("connect").onclick=connect;
$("clear").onclick=()=>{ticks=[];render();$("backtestOut").textContent="Data cleared."};
$("backtest").onclick=backtest;
setStatus("Disconnected");
